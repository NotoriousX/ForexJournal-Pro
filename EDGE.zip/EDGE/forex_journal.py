import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os
from datetime import datetime, timedelta
from pathlib import Path
import warnings
import json
import math
from scipy import stats
import yfinance as yf # Not used in current version, but kept if future features need it
from sklearn.linear_model import LinearRegression # Not used in current version
from sklearn.preprocessing import StandardScaler # Not used in current version
import base64 # Not used in current version

warnings.filterwarnings('ignore')

# --- ENHANCED COLOR PALETTE ---
TV_GREEN = '#26a69a'
TV_RED = '#ef5350'
TV_YELLOW = '#ffc82f'
TV_BLUE = '#2962ff'
TV_PURPLE = '#9c27b0'
TV_ORANGE = '#ff9800'
TV_CYAN = '#00bcd4'
TEXT_COLOR = '#d1d4dc'
BG_COLOR = '#0d1117'
PANEL_COLOR = '#161b22'
GRID_COLOR = '#21262d'
ACCENT_COLOR = '#58a6ff'
SUCCESS_COLOR = '#238636'
WARNING_COLOR = '#d29922'
ERROR_COLOR = '#da3633'

# --- PAGE SETUP ---
st.set_page_config(
    page_title="Forex Master Pro - Ultimate Backtesting Platform",
    layout="wide",
    page_icon="🚀",
    initial_sidebar_state="expanded"
)

# --- ENHANCED STYLING ---
st.markdown(f"""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&display=swap');
    
    * {{
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }}
    
    .stApp {{
        background: linear-gradient(135deg, {BG_COLOR} 0%, #0a0e1a 100%);
        color: {TEXT_COLOR};
    }}
    
    [data-testid=stSidebar] {{
        background: linear-gradient(180deg, {PANEL_COLOR} 0%, #1a1f2e 100%);
        border-right: 2px solid {GRID_COLOR};
        box-shadow: 4px 0 20px rgba(0,0,0,0.3);
    }}
    
    .main-header {{
        background: linear-gradient(135deg, {TV_BLUE} 0%, {TV_PURPLE} 100%);
        padding: 2rem;
        border-radius: 16px;
        margin-bottom: 2rem;
        text-align: center;
        box-shadow: 0 8px 32px rgba(41, 98, 255, 0.3);
        border: 1px solid rgba(88, 166, 255, 0.2);
    }}
    
    .main-title {{
        font-size: 3rem;
        font-weight: 700;
        background: linear-gradient(135deg, #ffffff 0%, #e6f3ff 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin: 0;
        text-shadow: 0 0 30px rgba(255,255,255,0.5);
    }}
    
    .main-subtitle {{
        font-size: 1.2rem;
        color: rgba(255,255,255,0.8);
        margin-top: 0.5rem;
        font-weight: 400;
    }}
    
    .metric-card {{
        background: linear-gradient(135deg, {PANEL_COLOR} 0%, rgba(33, 38, 45, 0.8) 100%);
        border: 1px solid {GRID_COLOR};
        padding: 1.5rem;
        border-radius: 12px;
        text-align: center;
        margin-bottom: 1rem;
        height: 100%;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        backdrop-filter: blur(10px);
    }}
    
    .metric-card::before {{
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, {TV_BLUE}, {TV_GREEN}, {TV_PURPLE});
        opacity: 0;
        transition: opacity 0.3s ease;
    }}
    
    .metric-card:hover {{
        transform: translateY(-4px);
        box-shadow: 0 12px 40px rgba(41, 98, 255, 0.2);
        border-color: {ACCENT_COLOR};
    }}
    
    .metric-card:hover::before {{
        opacity: 1;
    }}
    
    .metric-card-title {{
        font-size: 0.85rem;
        color: #8b949e;
        margin-bottom: 0.05rem;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }}
    
    .metric-value {{
        font-size: 2rem !important;
        font-weight: 700 !important;
        font-family: 'JetBrains Mono', monospace !important;
        line-height: 1.2;
    }}
    
    .metric-delta {{
        font-size: 0.75rem;
        color: #6e7681;
        margin-top: 0.5rem;
        font-weight: 500;
    }}
    
    .section-header {{
        background: linear-gradient(135deg, {PANEL_COLOR} 0%, rgba(33, 38, 45, 0.6) 100%);
        padding: 1rem 1.5rem;
        border-radius: 12px;
        margin: 2rem 0 1rem 0;
        border-left: 4px solid {TV_BLUE};
        backdrop-filter: blur(10px);
    }}
    
    .section-title {{
        font-size: 1.5rem;
        font-weight: 600;
        color: #e6edf3;
        margin: 0;
    }}
    
    .stat-grid {{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
        margin: 1rem 0;
    }}
    
    .stat-item {{
        background: rgba(22, 27, 34, 0.6);
        padding: 1rem;
        border-radius: 8px;
        border: 1px solid {GRID_COLOR};
        backdrop-filter: blur(5px);
    }}
    
    .stat-label {{
        font-size: 0.8rem;
        color: #8b949e;
        margin-bottom: 0.25rem;
    }}
    
    .stat-value {{
        font-size: 1.1rem;
        font-weight: 600;
        font-family: 'JetBrains Mono', monospace;
    }}
    
    .stButton>button {{
        background: linear-gradient(135deg, {TV_BLUE} 0%, {TV_PURPLE} 100%);
        color: white;
        border-radius: 8px;
        border: none;
        font-weight: 600;
        padding: 0.75rem 1.5rem;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(41, 98, 255, 0.3);
    }}
    
    .stButton>button:hover {{
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(41, 98, 255, 0.4);
    }}
    
    .stSelectbox>div>div>div {{
        background-color: {PANEL_COLOR};
        border: 1px solid {GRID_COLOR};
        border-radius: 8px;
    }}
    
    .alert-box {{
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
        border-left: 4px solid;
    }}
    
    .alert-success {{
        background: rgba(35, 134, 54, 0.1);
        border-color: {SUCCESS_COLOR};
        color: #7dd3fc;
    }}
    
    .alert-warning {{
        background: rgba(210, 153, 34, 0.1);
        border-color: {WARNING_COLOR};
        color: #fcd34d;
    }}
    
    .alert-error {{
        background: rgba(218, 54, 51, 0.1);
        border-color: {ERROR_COLOR};
        color: #fca5a5;
    }}
    
    .performance-badge {{
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        margin: 0.25rem;
    }}
    
    .badge-excellent {{ background: {SUCCESS_COLOR}; color: white; }}
    .badge-good {{ background: {TV_GREEN}; color: white; }}
    .badge-average {{ background: {WARNING_COLOR}; color: white; }}
    .badge-poor {{ background: {ERROR_COLOR}; color: white; }}
    
    .sidebar-section {{
        background: rgba(22, 27, 34, 0.4);
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
        border: 1px solid {GRID_COLOR};
    }}
    
    .trade-form {{
        background: linear-gradient(135deg, rgba(22, 27, 34, 0.8) 0%, rgba(33, 38, 45, 0.6) 100%);
        padding: 1.5rem;
        border-radius: 12px;
        border: 1px solid {GRID_COLOR};
        backdrop-filter: blur(10px);
    }}
</style>
""", unsafe_allow_html=True)

# --- SESSION STATE & INITIALIZATION ---
Path("journals").mkdir(exist_ok=True)
Path("exports").mkdir(exist_ok=True)
Path("strategies").mkdir(exist_ok=True)

def get_default_trade_df():
    """Returns an empty DataFrame with all expected columns and their dtypes."""
    return pd.DataFrame(columns=[
        'Date', 'Pair', 'Outcome', 'Risk%', 'R_Multiple', 'Strategy', 'Entry_Price',
        'Exit_Price', 'Position_Size', 'Comment', 'Equity', 'Session', 'Setup_Quality',
        'Market_Condition', 'Trade_Duration', 'MAE', 'MFE', 'Commission', 'Swap'
    ]).astype({
        'Date': 'datetime64[ns]', 'Pair': str, 'Outcome': str, 'Risk%': float,
        'R_Multiple': float, 'Strategy': str, 'Entry_Price': float, 'Exit_Price': float,
        'Position_Size': float, 'Comment': str, 'Equity': float, 'Session': str,
        'Setup_Quality': str, 'Market_Condition': str, 'Trade_Duration': int,
        'MAE': float, 'MFE': float, 'Commission': float, 'Swap': float
    })

def initialize_session_state():
    """Initializes session state variables with default values."""
    defaults = {
        'trades': get_default_trade_df(),
        'starting_equity': 10000.0,
        'equity': 10000.0,
        'current_journal': '',
        'risk_settings': {'max_risk': 2.0, 'max_correlation': 0.7, 'max_trades_per_day': 5},
        'alerts': [],
        'monte_carlo_runs': 1000,
        'confidence_level': 95,
        'backtest_period': 252,  # trading days
        'market_data_cache': {},
        'strategy_rules': {},
        'performance_targets': {'monthly_return': 5.0, 'max_drawdown': 10.0, 'sharpe_ratio': 1.5},
        'new_journal_name_input': '', # To retain input value
        # Add session state keys for R-multiple values to retain them
        'r_multiple_win_value': 2.0,
        'r_multiple_loss_value': -1.0,
    }
    
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value

initialize_session_state()

# --- HELPER FUNCTIONS FOR JOURNAL MANAGEMENT ---
def load_journal(journal_name):
    """Loads a selected journal into session state."""
    if not journal_name:
        st.warning("Please select a journal to load.")
        return
    
    journal_path = Path("journals") / f"{journal_name}.json"
    try:
        with open(journal_path, 'r') as f:
            data = json.load(f)
            
            loaded_trades_raw = data.get('trades', [])
            if not loaded_trades_raw:
                st.session_state.trades = get_default_trade_df()
            else:
                loaded_trades_df = pd.DataFrame(loaded_trades_raw)
                
                # Ensure 'Date' is datetime and other numerics are float
                loaded_trades_df['Date'] = pd.to_datetime(loaded_trades_df['Date'], errors='coerce')
                
                # Coerce numeric columns, fillna with 0 for safety
                numeric_cols = ['Risk%', 'R_Multiple', 'Entry_Price', 'Exit_Price', 'Position_Size', 
                                'Trade_Duration', 'MAE', 'MFE', 'Commission', 'Swap', 'Equity']
                for col in numeric_cols:
                    if col in loaded_trades_df.columns:
                        loaded_trades_df[col] = pd.to_numeric(loaded_trades_df[col], errors='coerce').fillna(0.0)
                    else:
                        loaded_trades_df[col] = 0.0 # Add missing numeric columns

                # Ensure all columns from default_trade_df are present
                default_df = get_default_trade_df()
                for col in default_df.columns:
                    if col not in loaded_trades_df.columns:
                        loaded_trades_df[col] = default_df[col].iloc[0] if not default_df.empty else None # Add missing columns
                
                # Reorder columns to match the initial DataFrame structure
                st.session_state.trades = loaded_trades_df[default_df.columns.tolist()]
                
            st.session_state.equity = data.get('equity', st.session_state.starting_equity)
            st.session_state.starting_equity = data.get('starting_equity', st.session_state.starting_equity)
            st.session_state.current_journal = journal_name
            st.success(f"Journal '{journal_name}' loaded successfully! 🎉")
            st.rerun() # Rerun to update dashboard metrics immediately

    except FileNotFoundError:
        st.error(f"Journal '{journal_name}' not found.")
    except Exception as e:
        st.error(f"Error loading journal: {e}")
        st.session_state.trades = get_default_trade_df() # Reset trades on error to prevent further issues

def save_journal(journal_name):
    """Saves the current session state as a journal."""
    if not journal_name:
        st.warning("Please create or select a journal name first.")
        return

    try:
        # Ensure 'Date' column is in a string format suitable for JSON serialization
        trades_for_save = st.session_state.trades.copy()
        if 'Date' in trades_for_save.columns:
            trades_for_save['Date'] = trades_for_save['Date'].dt.strftime('%Y-%m-%d')
        
        data = {
            'trades': trades_for_save.to_dict('records'),
            'equity': st.session_state.equity,
            'starting_equity': st.session_state.starting_equity
        }
        with open(Path("journals") / f"{journal_name}.json", 'w') as f:
            json.dump(data, f, indent=4)
        st.success(f"Journal '{journal_name}' saved successfully! 💾")
    except Exception as e:
        st.error(f"Error saving journal: {e}")

# --- ADVANCED ANALYTICS FUNCTIONS ---
def calculate_advanced_metrics(df):
    """Calculate comprehensive trading metrics"""
    if df.empty:
        return {
            'total_trades': 0, 'win_rate': 0.0, 'avg_win': 0.0, 'avg_loss': 0.0,
            'expectancy': 0.0, 'profit_factor': 0.0, 'sharpe_ratio': 0.0,
            'sortino_ratio': 0.0, 'max_drawdown': 0.0, 'max_win_streak': 0,
            'max_loss_streak': 0, 'kelly_percentage': 0.0, 'calmar_ratio': 0.0,
            'net_profit': 0.0, 'total_commission': 0.0, 'total_swap': 0.0
        }
    
    df_calc = df.copy() # Work on a copy to avoid modifying the original DataFrame

    # Ensure relevant columns are numeric, coercing errors to NaN and then filling with 0
    numeric_cols = ['R_Multiple', 'Risk%', 'Commission', 'Swap', 'Equity']
    for col in numeric_cols:
        if col in df_calc.columns:
            df_calc[col] = pd.to_numeric(df_calc[col], errors='coerce').fillna(0.0)
        else:
            df_calc[col] = 0.0 # Add the column if it's missing, default to 0

    # Basic metrics
    total_trades = len(df_calc)
    wins = df_calc[df_calc['R_Multiple'] > 0]
    losses = df_calc[df_calc['R_Multiple'] < 0]
    
    win_rate = len(wins) / total_trades * 100 if total_trades > 0 else 0
    avg_win = wins['R_Multiple'].mean() if len(wins) > 0 else 0
    avg_loss = abs(losses['R_Multiple'].mean()) if len(losses) > 0 else 0 # Absolute value for avg loss

    # Net Profit
    # Use the Equity column from the DataFrame, which is already correctly calculated/updated
    net_profit = df_calc['Equity'].iloc[-1] - df_calc['Equity'].iloc[0] if len(df_calc) > 0 else 0.0
    total_commission = df_calc['Commission'].sum()
    total_swap = df_calc['Swap'].sum()

    # Advanced metrics
    expectancy = (win_rate/100 * avg_win) - ((100-win_rate)/100 * avg_loss) if total_trades > 0 else 0
    
    total_wins_R = wins['R_Multiple'].sum()
    total_losses_R = abs(losses['R_Multiple'].sum()) # Absolute value for sum of losses in R
    profit_factor = total_wins_R / total_losses_R if total_losses_R > 0 else float('inf')
    
    # Risk metrics
    returns = df_calc['R_Multiple'].values # Using R_Multiple for Sharpe/Sortino
    sharpe_ratio = 0.0
    sortino_ratio = 0.0
    if len(returns) > 1: # Need at least 2 data points for std dev
        if np.std(returns) > 0:
            sharpe_ratio = np.mean(returns) / np.std(returns) * np.sqrt(252) # Annualized
        downside_returns = returns[returns < 0]
        if len(downside_returns) > 0 and np.std(downside_returns) > 0:
            sortino_ratio = np.mean(returns) / np.std(downside_returns) / np.sqrt(252) # Annualized, fixed incorrect multiplication
    
    # Drawdown analysis
    max_drawdown = 0.0
    if len(df_calc) > 0:
        equity_curve_for_drawdown = df_calc['Equity'].values
        # Handle cases where starting equity is 0 or all equity values are 0
        if len(equity_curve_for_drawdown) > 0 and equity_curve_for_drawdown[0] != 0 and np.max(equity_curve_for_drawdown) != 0:
            peak = np.maximum.accumulate(equity_curve_for_drawdown)
            # Avoid division by zero if peak remains zero (e.g., all equity values are zero)
            drawdown_pct = np.where(peak > 0, (equity_curve_for_drawdown - peak) / peak * 100, 0)
            max_drawdown = np.min(drawdown_pct)
        else: # If all equity is zero or starts at zero
            max_drawdown = 0.0 # Or some other appropriate value
    
    # Streak analysis
    streaks = []
    current_streak = 0
    for r in returns:
        if r > 0:
            current_streak = current_streak + 1 if current_streak > 0 else 1
        elif r < 0:
            current_streak = current_streak - 1 if current_streak < 0 else -1
        else: # Breakeven
            if current_streak > 0:
                streaks.append(current_streak)
            elif current_streak < 0:
                streaks.append(current_streak)
            current_streak = 0
    # Add the last streak if it's not zero
    if current_streak != 0:
        streaks.append(current_streak)

    max_win_streak = max([s for s in streaks if s > 0], default=0)
    max_loss_streak = abs(min([s for s in streaks if s < 0], default=0))
    
    # Kelly Criterion
    kelly_f = 0.0
    if avg_loss > 0 and avg_win > 0:
        kelly_f = (win_rate/100) - ((1 - win_rate/100) / (avg_win / avg_loss))
    elif avg_win > 0 and avg_loss == 0: # All wins, avg_loss is 0
         kelly_f = win_rate/100 # Can bet full amount up to 100% (theoretically)
    
    kelly_pct = kelly_f * 100

    # Calmar Ratio
    calmar_ratio = 0.0
    if max_drawdown != 0 and len(df_calc) > 0 and df_calc['Equity'].iloc[0] != 0:
        # Annualized return calculation for Calmar Ratio
        total_years = (df_calc['Date'].max() - df_calc['Date'].min()).days / 365.25 if len(df_calc) > 1 else 1
        if total_years == 0: total_years = 1 # Avoid division by zero for short periods
        
        annualized_return = (df_calc['Equity'].iloc[-1] / df_calc['Equity'].iloc[0])**(1/total_years) - 1
        calmar_ratio = annualized_return / abs(max_drawdown / 100) if abs(max_drawdown) > 0 else 0
    
    return {
        'total_trades': total_trades,
        'win_rate': win_rate,
        'avg_win': avg_win,
        'avg_loss': avg_loss,
        'expectancy': expectancy,
        'profit_factor': profit_factor,
        'sharpe_ratio': sharpe_ratio,
        'sortino_ratio': sortino_ratio,
        'max_drawdown': max_drawdown,
        'max_win_streak': max_win_streak,
        'max_loss_streak': max_loss_streak,
        'kelly_percentage': kelly_pct,
        'calmar_ratio': calmar_ratio,
        'net_profit': net_profit,
        'total_commission': total_commission,
        'total_swap': total_swap
    }

def monte_carlo_simulation(df, runs=1000, periods=252):
    """Perform Monte Carlo simulation on trade results"""
    if df.empty or 'R_Multiple' not in df.columns or 'Risk%' not in df.columns:
        return None
    
    # Calculate 'Return_on_Equity_Pct' based on historical R_Multiple and Risk%
    df_sim = df.copy()
    df_sim['R_Multiple'] = pd.to_numeric(df_sim['R_Multiple'], errors='coerce').fillna(0)
    df_sim['Risk%'] = pd.to_numeric(df_sim['Risk%'], errors='coerce').fillna(0)
    
    # The return on equity for a trade is R_Multiple * (Risk% / 100)
    # Filter out trades with 0 risk or 0 R_Multiple as they don't contribute to equity change
    returns_on_equity_pct = (df_sim['R_Multiple'] * df_sim['Risk%']).dropna().values
    returns_on_equity_pct = returns_on_equity_pct[returns_on_equity_pct != 0] # Only consider trades that actually change equity

    if len(returns_on_equity_pct) < 2: # Need at least 2 distinct returns to sample meaningfully
        return None

    simulations_final_returns = []
    for _ in range(runs):
        # Sample with replacement
        sim_returns_equity_pct = np.random.choice(returns_on_equity_pct, size=periods, replace=True)
        
        simulated_equity = np.zeros(periods + 1)
        simulated_equity[0] = st.session_state.starting_equity
        
        for i in range(periods):
            # Prevent equity from going below 0 (simplified ruin model)
            if simulated_equity[i] <= 0:
                simulated_equity[i+1] = 0
            else:
                simulated_equity[i+1] = simulated_equity[i] * (1 + sim_returns_equity_pct[i] / 100)
                
        simulations_final_returns.append((simulated_equity[-1] / simulated_equity[0] - 1) * 100)
    
    if not simulations_final_returns:
        return None

    return {
        'simulations': simulations_final_returns,
        'percentiles': {
            '5th': np.percentile(simulations_final_returns, 5),
            '25th': np.percentile(simulations_final_returns, 25),
            '50th': np.percentile(simulations_final_returns, 50),
            '75th': np.percentile(simulations_final_returns, 75),
            '95th': np.percentile(simulations_final_returns, 95)
        },
        'probability_profit': len([s for s in simulations_final_returns if s > 0]) / len(simulations_final_returns) * 100 if simulations_final_returns else 0
    }

def create_advanced_metric_card(title, value, delta=None, color=None, icon=None, trend=None):
    """Create enhanced metric cards with animations and trends"""
    delta_html = f'<div class="metric-delta">{delta}</div>' if delta else ""
    color_style = f'color: {color};' if color else ""
    icon_html = f'<div style="font-size: 1.5rem; margin-bottom: 0.5rem;">{icon}</div>' if icon else ""
    
    trend_arrow = ""
    if trend == "up":
        trend_arrow = "⬆️"
    elif trend == "down":
        trend_arrow = "⬇️"
    elif trend == "stable":
        trend_arrow = "➡️"
    
    st.markdown(f"""
    <div class="metric-card">
        {icon_html}
        <div class="metric-card-title">{title} {trend_arrow}</div>
        <div class="metric-value" style="{color_style}">{value}</div>
        {delta_html}
    </div>
    """, unsafe_allow_html=True)

def performance_grade(metrics):
    """Grade overall performance"""
    score = 0
    
    # Win rate (0-25 points)
    if metrics.get('win_rate', 0) >= 60:
        score += 25
    elif metrics.get('win_rate', 0) >= 50:
        score += 20
    elif metrics.get('win_rate', 0) >= 40:
        score += 15
    elif metrics.get('win_rate', 0) >= 30:
        score += 10
    
    # Profit factor (0-25 points)
    pf = metrics.get('profit_factor', 0)
    if pf >= 2.0:
        score += 25
    elif pf >= 1.5:
        score += 20
    elif pf >= 1.2:
        score += 15
    elif pf >= 1.0:
        score += 10
    
    # Sharpe ratio (0-25 points)
    sr = metrics.get('sharpe_ratio', 0)
    if sr >= 2.0:
        score += 25
    elif sr >= 1.5:
        score += 20
    elif sr >= 1.0:
        score += 15
    elif sr >= 0.5:
        score += 10
    
    # Max drawdown (0-25 points)
    dd = abs(metrics.get('max_drawdown', 100))
    if dd <= 5:
        score += 25
    elif dd <= 10:
        score += 20
    elif dd <= 15:
        score += 15
    elif dd <= 20:
        score += 10
    
    if score >= 85:
        return "A+", SUCCESS_COLOR
    elif score >= 75:
        return "A", TV_GREEN
    elif score >= 65:
        return "B", WARNING_COLOR
    elif score >= 50:
        return "C", TV_ORANGE
    else:
        return "F", ERROR_COLOR

# --- SIDEBAR ---
with st.sidebar:
    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("### 🎯 Trading Command Center")
    
    # Performance Overview
    if not st.session_state.trades.empty:
        metrics = calculate_advanced_metrics(st.session_state.trades)
        grade, grade_color = performance_grade(metrics)
        
        st.markdown(f"""
        <div style="text-align: center; padding: 1rem; background: linear-gradient(135deg, {grade_color}20, {grade_color}10); 
                    border-radius: 8px; margin: 1rem 0; border: 1px solid {grade_color};">
            <div style="font-size: 2rem; font-weight: 700; color: {grade_color};">Grade: {grade}</div>
            <div style="font-size: 0.9rem; color: #8b949e;">Performance Rating</div>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div style="text-align: center; padding: 1rem; background: linear-gradient(135deg, {GRID_COLOR}20, {GRID_COLOR}10); 
                    border-radius: 8px; margin: 1rem 0; border: 1px solid {GRID_COLOR};">
            <div style="font-size: 1.5rem; font-weight: 700; color: {TEXT_COLOR};">No Data Yet</div>
            <div style="font-size: 0.8rem; color: #8b949e;">Add trades to see performance!</div>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Journal Management
    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("### 📂 Journal Management")
    
    journal_files = [f.stem for f in Path("journals").glob("*.json")]
    
    # Determine initial index for selectbox
    selected_journal_index = 0
    if st.session_state.current_journal and st.session_state.current_journal in journal_files:
        selected_journal_index = journal_files.index(st.session_state.current_journal) + 1 # +1 for the empty string
    
    selected_journal_name = st.selectbox(
        "Select Journal", 
        [""] + sorted(journal_files), # Sort for consistent order
        index=selected_journal_index, 
        key="select_journal_box",
        help="Choose an existing journal to load its trades."
    )
    
    col1_journal, col2_journal = st.columns(2)
    with col1_journal:
        if st.button("📁 Load Selected", use_container_width=True):
            if selected_journal_name:
                load_journal(selected_journal_name)
            else:
                st.warning("Please select a journal to load.")
    with col2_journal:
        if st.session_state.current_journal:
            if st.button(f"💾 Save '{st.session_state.current_journal}'", use_container_width=True):
                save_journal(st.session_state.current_journal)
        else:
            st.button("💾 Save (No Journal Selected)", use_container_width=True, disabled=True)

    st.markdown("---") # Separator for new journal creation
    st.write("Create New Journal:")
    # Using a key that links to session_state to retain value
    new_journal_name = st.text_input("New Journal Name", value=st.session_state.new_journal_name_input, placeholder="Enter journal name...", key="new_journal_name_input_widget")
    
    if st.button("➕ Create & Set", use_container_width=True):
        if new_journal_name:
            if new_journal_name != st.session_state.current_journal:
                st.session_state.current_journal = new_journal_name
                st.session_state.trades = get_default_trade_df() # Clear trades for new journal
                st.session_state.equity = st.session_state.starting_equity # Reset equity for new journal
                st.session_state.new_journal_name_input = new_journal_name # Update session state for text input
                st.success(f"New journal '{new_journal_name}' created and set. Add your first trade! (Saved upon adding trades)")
                st.rerun() # Rerun to refresh the app state
            else:
                st.info(f"Journal '{new_journal_name}' is already the current journal. Add trades to it.")
        else:
            st.error("Please enter a name for the new journal.")

    st.markdown("---")
    st.write("Initial Capital & Session Balance:")
    # Allow user to set starting equity
    new_starting_equity = st.number_input("Set Initial Account Balance ($)", value=st.session_state.starting_equity, min_value=0.0, format="%.2f", key="starting_equity_input")
    if new_starting_equity != st.session_state.starting_equity:
        st.session_state.starting_equity = new_starting_equity
        st.session_state.equity = new_starting_equity # Update current equity too, as it will be used for next calculation
        st.success("Initial Account Balance updated. Re-calculate equity curve by adding trades or reloading data.")
        st.rerun()

    if st.button("Reset Current Equity to Initial Balance", use_container_width=True, help="Resets your current account balance for calculations to the initial balance set above. This will recalculate historical trades from this point."):
        st.session_state.equity = st.session_state.starting_equity
        # The main logic will re-calculate df['Equity'] based on this new starting_equity
        st.success(f"Current account balance reset to ${st.session_state.starting_equity:,.2f}.")
        st.rerun()

    st.markdown('</div>', unsafe_allow_html=True)
    
    # Trade Entry Form
    st.markdown('<div class="trade-form">', unsafe_allow_html=True)
    st.markdown("### 📝 Add New Trade")
    
    with st.form("advanced_trade_form", clear_on_submit=False): 
        col1, col2 = st.columns(2)
        
        with col1:
            trade_date = st.date_input("📅 Date", datetime.today(), key="trade_date_input")
            pairs = ['EURUSD', 'GBPUSD', 'USDJPY', 'USDCHF', 'AUDUSD', 'USDCAD', 'NZDUSD', 
                     'EURJPY', 'GBPJPY', 'EURGBP', 'EURAUD', 'GBPAUD', 'AUDCAD', 'AUDNZD', 'XAUUSD', 'Other']
            pair = st.selectbox("💱 Pair", pairs, key="pair_select")
            outcome = st.radio("🎯 Outcome", ["Win", "Loss", "Breakeven"], horizontal=True, key="outcome_radio")
        
        with col2:
            risk_pct = st.number_input("⚠️ Risk (%)", 0.01, 10.0, 1.0, 0.01, key="risk_pct_input")
            
            # --- MODIFIED LOGIC FOR R-MULTIPLE INPUT ---
            if outcome == "Win":
                default_r = st.session_state.get('r_multiple_win_value', 2.0) 
                r_multiple = st.number_input("📈 Reward (R)", 0.01, 20.0, default_r, 0.1, key="r_multiple_win")
                st.session_state['r_multiple_win_value'] = r_multiple
            elif outcome == "Loss":
                default_r = st.session_state.get('r_multiple_loss_value', -1.0)
                r_multiple = st.number_input("📉 Loss (R)", -20.0, -0.01, default_r, 0.1, key="r_multiple_loss")
                st.session_state['r_multiple_loss_value'] = r_multiple
            else: # Breakeven
                r_multiple = st.number_input("✨ R-Multiple (Breakeven)", value=0.0, format="%.2f", disabled=True, key="r_multiple_breakeven")
            # --- END MODIFIED LOGIC ---
            
            session = st.selectbox("🌍 Session", ["London", "New York", "Asia", "Sydney", "Overlap", "N/A"], key="session_select")
        
        with st.expander("🔧 Advanced Details"):
            col3, col4 = st.columns(2)
            with col3:
                strategy = st.text_input("📋 Strategy", placeholder="e.g., Breakout", key="strategy_input")
                setup_quality = st.selectbox("⭐ Setup Quality", ["A+", "A", "B", "C", "D", "N/A"], key="setup_quality_select")
                entry_price = st.number_input("🎯 Entry Price", value=0.0, format="%.5f", key="entry_price_input")
                exit_price = st.number_input("🚪 Exit Price", value=0.0, format="%.5f", key="exit_price_input")
                
            with col4:
                market_condition = st.selectbox("🌊 Market", ["Trending", "Ranging", "Volatile", "Quiet", "N/A"], key="market_condition_select")
                duration = st.number_input("⏱️ Duration (min)", 0, 14400, 60, key="duration_input") # Increased max duration
                commission = st.number_input("💰 Commission", value=0.0, format="%.2f", key="commission_input")
                swap = st.number_input("🔄 Swap", value=0.0, format="%.2f", key="swap_input")

            # Add MAE and MFE inputs
            mae = st.number_input("🔻 MAE (Max Adverse Excursion in pips)", value=0.0, format="%.1f", help="Max adverse movement from entry price", key="mae_input")
            mfe = st.number_input("⬆️ MFE (Max Favorable Excursion in pips)", value=0.0, format="%.1f", help="Max favorable movement from entry price", key="mfe_input")
            
            comment = st.text_area("💭 Comments", placeholder="Trade notes...", key="comment_input")
        
        submitted = st.form_submit_button("🚀 Add Trade", use_container_width=True)
        
        if submitted:
            if not st.session_state.current_journal:
                st.error("⚠️ Please create or load a journal first!")
            else:
                # Calculate new equity
                capital_at_risk = st.session_state.equity * (risk_pct / 100)
                profit_loss = capital_at_risk * r_multiple
                new_equity = st.session_state.equity + profit_loss - commission - swap
                
                new_trade = {
                    'Date': trade_date,
                    'Pair': pair,
                    'Outcome': outcome,
                    'Risk%': risk_pct,
                    'R_Multiple': r_multiple,
                    'Strategy': strategy if strategy else "N/A", # Ensure default if empty
                    'Entry_Price': entry_price,
                    'Exit_Price': exit_price,
                    'Position_Size': capital_at_risk, # This is the actual risked amount
                    'Comment': comment if comment else "", # Ensure default if empty
                    'Equity': new_equity, # This is the updated equity after this trade
                    'Session': session,
                    'Setup_Quality': setup_quality,
                    'Market_Condition': market_condition,
                    'Trade_Duration': duration,
                    'MAE': mae, # Added MAE
                    'MFE': mfe, # Added MFE
                    'Commission': commission,
                    'Swap': swap
                }
                
                # Append new trade to DataFrame
                new_trade_df = pd.DataFrame([new_trade])
                
                # Ensure all columns match the default DataFrame structure and dtypes
                # This handles cases where older journals might not have all columns or new ones are added
                default_df_template = get_default_trade_df()
                
                # Align columns between new_trade_df and default_df_template
                for col in default_df_template.columns:
                    if col not in new_trade_df.columns:
                        new_trade_df[col] = default_df_template[col].iloc[0] if not default_df_template.empty else None
                new_trade_df = new_trade_df[default_df_template.columns.tolist()]
                
                # Ensure existing session_state.trades also has all columns from default_df_template
                for col in default_df_template.columns:
                    if col not in st.session_state.trades.columns:
                        st.session_state.trades[col] = default_df_template[col].iloc[0] if not default_df_template.empty else None

                # Convert to correct dtypes before concat, especially 'Date'
                st.session_state.trades['Date'] = pd.to_datetime(st.session_state.trades['Date'], errors='coerce')
                new_trade_df['Date'] = pd.to_datetime(new_trade_df['Date'], errors='coerce')

                # Coerce numeric columns to ensure type consistency before concat
                numeric_cols = ['Risk%', 'R_Multiple', 'Entry_Price', 'Exit_Price', 'Position_Size', 
                                'Trade_Duration', 'MAE', 'MFE', 'Commission', 'Swap', 'Equity']
                for col in numeric_cols:
                    st.session_state.trades[col] = pd.to_numeric(st.session_state.trades[col], errors='coerce').fillna(0.0)
                    new_trade_df[col] = pd.to_numeric(new_trade_df[col], errors='coerce').fillna(0.0)

                st.session_state.trades = pd.concat([st.session_state.trades, new_trade_df], ignore_index=True)

                # Update the global equity in session state
                st.session_state.equity = new_equity
                
                # Save after adding trade to ensure persistence
                save_journal(st.session_state.current_journal)
                st.success("✅ Trade added and journal saved!")
                st.rerun() # Rerun to update dashboard metrics immediately
    
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Risk Management
    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("### ⚡ Risk Management Settings")
    
    max_risk = st.slider("Max Risk per Trade (%)", 0.1, 5.0, st.session_state.risk_settings['max_risk'], 0.1, key="max_risk_slider")
    max_correlation = st.slider("Max Correlation (placeholder)", 0.1, 1.0, st.session_state.risk_settings['max_correlation'], 0.1, key="max_correlation_slider")
    max_trades_day = st.slider("Max Trades/Day", 1, 10, st.session_state.risk_settings['max_trades_per_day'], key="max_trades_day_slider")
    
    st.session_state.risk_settings = {
        'max_risk': max_risk,
        'max_correlation': max_correlation,
        'max_trades_per_day': max_trades_day
    }

    st.markdown('</div>', unsafe_allow_html=True)

    # Performance Targets
    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("### 📈 Performance Targets")
    st.session_state.performance_targets['monthly_return'] = st.number_input("Target Monthly Return (%)", 0.0, 50.0, st.session_state.performance_targets['monthly_return'], 0.5, key="target_monthly_return")
    st.session_state.performance_targets['max_drawdown'] = st.number_input("Max Acceptable Drawdown (%)", 0.0, 50.0, st.session_state.performance_targets['max_drawdown'], 0.5, key="target_max_drawdown")
    st.session_state.performance_targets['sharpe_ratio'] = st.number_input("Target Sharpe Ratio", 0.0, 5.0, st.session_state.performance_targets['sharpe_ratio'], 0.1, key="target_sharpe_ratio")
    st.markdown('</div>', unsafe_allow_html=True)

# --- MAIN DASHBOARD ---
st.markdown(f"""
<div class="main-header">
    <h1 class="main-title">🚀 Forex Master Pro</h1>
    <p class="main-subtitle">Ultimate Backtesting & Analytics Platform</p>
</div>
""", unsafe_allow_html=True)

if st.session_state.trades.empty:
    st.markdown("""
    <div class="alert-box alert-warning">
        <h3>🎯 Welcome to Forex Master Pro!</h3>
        <p>Your ultimate trading analytics platform is ready. Add your first trade from the sidebar to unlock powerful insights:</p>
        <ul>
            <li>📊 Advanced performance metrics & grading</li>
            <li>🎲 Monte Carlo risk simulations</li>
            <li>📈 Interactive equity curves & heatmaps</li>
            <li>🔬 Deep strategy analysis</li>
            <li>⚡ Real-time risk management</li>
        </ul>
        <p>Start by creating or loading a journal in the sidebar.</p>
    </div>
    """, unsafe_allow_html=True)
else:
    df = st.session_state.trades.copy()
    df['Date'] = pd.to_datetime(df['Date'])
    df = df.sort_values('Date').reset_index(drop=True)
    
    # Recalculate Equity to ensure consistency from start
    # This loop assumes trades are sorted by date.
    if not df.empty:
        current_calculated_equity = st.session_state.starting_equity
        equity_series = []
        for index, row in df.iterrows():
            # Safely convert to numeric, default to 0 if conversion fails or NaN
            risk_pct_val = pd.to_numeric(row['Risk%'], errors='coerce')
            if pd.isna(risk_pct_val):
                risk_pct_val = 0.0
            
            r_multiple_val = pd.to_numeric(row['R_Multiple'], errors='coerce')
            if pd.isna(r_multiple_val):
                r_multiple_val = 0.0
            
            commission_val = pd.to_numeric(row['Commission'], errors='coerce')
            if pd.isna(commission_val):
                commission_val = 0.0
            
            swap_val = pd.to_numeric(row['Swap'], errors='coerce')
            if pd.isna(swap_val):
                swap_val = 0.0

            capital_at_risk = current_calculated_equity * (risk_pct_val / 100)
            profit_loss = capital_at_risk * r_multiple_val
            current_calculated_equity += (profit_loss - commission_val - swap_val)
            equity_series.append(current_calculated_equity)
        df['Equity'] = equity_series
        st.session_state.equity = current_calculated_equity # Update global equity after recalculation
    else:
        # If df is empty after filtering/reloading, ensure equity is reset
        st.session_state.equity = st.session_state.starting_equity


    # Calculate comprehensive metrics
    metrics = calculate_advanced_metrics(df)
    
    # Performance Grade Section
    grade, grade_color = performance_grade(metrics)
    
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown(f"""
        <div style="text-align: center; padding: 2rem; background: linear-gradient(135deg, {grade_color}20, {grade_color}10); 
                    border-radius: 16px; margin: 2rem 0; border: 2px solid {grade_color}; box-shadow: 0 8px 32px {grade_color}30;">
            <div style="font-size: 4rem; font-weight: 700; color: {grade_color}; margin-bottom: 0.5rem;">{grade}</div>
            <div style="font-size: 1.2rem; color: #e6edf3; font-weight: 600;">Overall Performance Grade</div>
            <div style="font-size: 0.9rem; color: #8b949e; margin-top: 0.5rem;">Based on Win Rate, Profit Factor, Sharpe Ratio & Drawdown</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Key Performance Indicators
    st.markdown('<div class="section-header"><h2 class="section-title">📊 Key Performance Indicators</h2></div>', unsafe_allow_html=True)
    
    cols = st.columns(6)
    
    with cols[0]:
        profit = metrics['net_profit']
        profit_pct = (profit / st.session_state.starting_equity) * 100 if st.session_state.starting_equity != 0 else 0
        create_advanced_metric_card(
            "Total P&L", f"${profit:,.0f}", f"{profit_pct:+.1f}%", 
            TV_GREEN if profit >= 0 else TV_RED, "💰", 
            "up" if profit > 0 else "down" if profit < 0 else "stable"
        )
    
    with cols[1]:
        create_advanced_metric_card(
            "Win Rate", f"{metrics['win_rate']:.1f}%", f"{len(df[df['Outcome']=='Win'])}/{metrics['total_trades']}", 
            TV_GREEN if metrics['win_rate'] >= 50 else TV_RED, "🎯",
            "up" if metrics['win_rate'] >= 50 else "down"
        )
    
    with cols[2]:
        create_advanced_metric_card(
            "Profit Factor", f"{metrics['profit_factor']:.2f}", "Risk/Reward Balance", 
            TV_GREEN if metrics['profit_factor'] >= 1.5 else TV_YELLOW if metrics['profit_factor'] >= 1.0 else TV_RED, 
            "⚖️", "up" if metrics['profit_factor'] >= 1.5 else "stable" if metrics['profit_factor'] >= 1.0 else "down"
        )
    
    with cols[3]:
        create_advanced_metric_card(
            "Sharpe Ratio", f"{metrics['sharpe_ratio']:.2f}", "Risk-Adj. Return", 
            TV_GREEN if metrics['sharpe_ratio'] >= 1.0 else TV_YELLOW if metrics['sharpe_ratio'] >= 0.5 else TV_RED, 
            "📈", "up" if metrics['sharpe_ratio'] >= 1.0 else "stable" if metrics['sharpe_ratio'] >= 0.5 else "down"
        )
    
    with cols[4]:
        create_advanced_metric_card(
            "Max Drawdown", f"{metrics['max_drawdown']:.1f}%", "Peak to Trough", 
            TV_GREEN if metrics['max_drawdown'] >= -10 else TV_YELLOW if metrics['max_drawdown'] >= -20 else TV_RED, 
            "📉", "up" if metrics['max_drawdown'] >= -10 else "stable" if metrics['max_drawdown'] >= -20 else "down"
        )
    
    with cols[5]:
        create_advanced_metric_card(
            "Expectancy", f"{metrics['expectancy']:.3f}R", "Per Trade Expected", 
            TV_GREEN if metrics['expectancy'] > 0.2 else TV_YELLOW if metrics['expectancy'] > 0 else TV_RED, 
            "🎲", "up" if metrics['expectancy'] > 0.2 else "stable" if metrics['expectancy'] > 0 else "down"
        )
    
    # Advanced Metrics Row
    cols2 = st.columns(6)
    
    with cols2[0]:
        create_advanced_metric_card(
            "Kelly %", f"{metrics['kelly_percentage']:.1f}%", "Optimal Position Size", 
            TV_BLUE, "🧮", "stable"
        )
    
    with cols2[1]:
        create_advanced_metric_card(
            "Sortino Ratio", f"{metrics['sortino_ratio']:.2f}", "Downside Risk Adj.", 
            TV_PURPLE, "📊", "stable"
        )
    
    with cols2[2]:
        create_advanced_metric_card(
            "Calmar Ratio", f"{metrics['calmar_ratio']:.2f}", "Return/Drawdown", 
            TV_CYAN, "📋", "stable"
        )
    
    with cols2[3]:
        create_advanced_metric_card(
            "Win Streak", f"{metrics['max_win_streak']}", "Consecutive Wins", 
            TV_GREEN, "🔥", "up"
        )
    
    with cols2[4]:
        create_advanced_metric_card(
            "Loss Streak", f"{metrics['max_loss_streak']}", "Consecutive Losses", 
            TV_RED, "❄️", "down"
        )
    
    with cols2[5]:
        current_equity = st.session_state.equity
        create_advanced_metric_card(
            "Current Equity", f"${current_equity:,.0f}", f"${current_equity - st.session_state.starting_equity:+,.0f}", 
            TV_BLUE, "💎", "stable"
        )
    
    # Monte Carlo Analysis
    st.markdown('<div class="section-header"><h2 class="section-title">🎲 Monte Carlo Risk Analysis</h2></div>', unsafe_allow_html=True)
    
    monte_carlo = monte_carlo_simulation(df, st.session_state.monte_carlo_runs, st.session_state.backtest_period)
    
    if monte_carlo and monte_carlo['simulations'] and len(monte_carlo['simulations']) > 0: # Ensure simulations are not empty
        col1, col2 = st.columns([2, 1])
        
        with col1:
            # Monte Carlo Distribution
            fig_mc = go.Figure()
            fig_mc.add_trace(go.Histogram(
                x=monte_carlo['simulations'],
                nbinsx=50,
                name='Simulated Returns',
                marker_color=TV_BLUE,
                opacity=0.7
            ))
            
            # Add percentile lines
            for percentile, color in [('5th', TV_RED), ('25th', TV_ORANGE), ('50th', TV_YELLOW), ('75th', TV_GREEN), ('95th', TV_CYAN)]:
                fig_mc.add_vline(
                    x=monte_carlo['percentiles'][percentile],
                    line_dash="dash",
                    line_color=color,
                    annotation_text=f"{percentile}: {monte_carlo['percentiles'][percentile]:.1f}%",
                    annotation_position="top right"
                )
            
            fig_mc.update_layout(
                title='<b>Monte Carlo Simulation - Return Distribution</b>',
                xaxis_title='Projected Returns (%)',
                yaxis_title='Frequency',
                template='plotly_dark',
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                height=400,
                font=dict(color=TEXT_COLOR)
            )
            st.plotly_chart(fig_mc, use_container_width=True)
        
        with col2:
            st.markdown(f"""
            <div class="stat-grid">
                <div class="stat-item">
                    <div class="stat-label">Probability of Profit</div>
                    <div class="stat-value" style="color: {TV_GREEN};">{monte_carlo['probability_profit']:.1f}%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">5th Percentile (VaR)</div>
                    <div class="stat-value" style="color: {TV_RED};">{monte_carlo['percentiles']['5th']:.1f}%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">Expected Return</div>
                    <div class="stat-value" style="color: {TV_YELLOW};">{monte_carlo['percentiles']['50th']:.1f}%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">95th Percentile</div>
                    <div class="stat-value" style="color: {TV_CYAN};">{monte_carlo['percentiles']['95th']:.1f}%</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">Simulation Runs</div>
                    <div class="stat-value">{st.session_state.monte_carlo_runs:,}</div>
                </div>
                <div class="stat-item">
                    <div class="stat-label">Backtest Period (days)</div>
                    <div class="stat-value">{st.session_state.backtest_period:,}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="alert-box alert-warning">
            <p><strong>📊 Insufficient data for Monte Carlo Simulation.</strong></p>
            <p>Please add more trades with valid 'R_Multiple' and 'Risk%' values (at least 2 distinct trades with non-zero returns) to enable this powerful analysis.</p>
        </div>
        """, unsafe_allow_html=True)
        
    # Advanced Charting Section
    st.markdown('<div class="section-header"><h2 class="section-title">📈 Advanced Analytics</h2></div>', unsafe_allow_html=True)
    
    tab1, tab2, tab3, tab4, tab5 = st.tabs(["📊 Equity & Drawdown", "🎯 Performance Heatmaps", "🔍 Trade Analysis", "⚡ Risk Metrics", "📈 Strategy Optimization"])
    
    with tab1:
        # Enhanced Equity Curve with Drawdown (ACCOUNT BALANCE OVER TIME)
        if not df.empty and 'Equity' in df.columns and not df['Equity'].isnull().all():
            fig_equity = make_subplots(
                rows=2, cols=1,
                shared_xaxes=True,
                vertical_spacing=0.1,
                subplot_titles=('Compounding Account Balance Over Time', 'Drawdown'), # Updated title
                row_heights=[0.7, 0.3]
            )
            
            # Equity curve
            fig_equity.add_trace(
                go.Scatter(
                    x=df['Date'], y=df['Equity'],
                    mode='lines',
                    name='Equity',
                    line=dict(color=TV_GREEN, width=3),
                    fill='tonexty',
                    fillcolor='rgba(38, 166, 154, 0.1)',
                    hovertemplate="<b>Date: %{x|%Y-%m-%d}</b><br>Equity: $%{y:,.2f}<extra></extra>"
                ),
                row=1, col=1
            )
            
            # Benchmark line (starting equity)
            fig_equity.add_hline(
                y=st.session_state.starting_equity,
                line_dash="dash",
                line_color=TV_YELLOW,
                annotation_text=f"Starting Capital: ${st.session_state.starting_equity:,.0f}",
                annotation_position="top left",
                row=1, col=1
            )
            
            # Drawdown
            equity_curve = df['Equity'].values
            peak = np.maximum.accumulate(equity_curve)
            # Handle division by zero for drawdown if peak is 0
            drawdown_pct = np.where(peak != 0, (equity_curve - peak) / peak * 100, 0)
            
            fig_equity.add_trace(
                go.Scatter(
                    x=df['Date'], y=drawdown_pct,
                    mode='lines',
                    name='Drawdown',
                    line=dict(color=TV_RED, width=2),
                    fill='tozeroy',
                    fillcolor='rgba(239, 83, 80, 0.2)',
                    hovertemplate="<b>Date: %{x|%Y-%m-%d}</b><br>Drawdown: %{y:.2f}%<extra></extra>"
                ),
                row=2, col=1
            )
            
            fig_equity.update_layout(
                title='<b>Compounding Account Balance & Drawdown Analysis</b>', # Updated title
                template='plotly_dark',
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                height=600,
                showlegend=True,
                hovermode="x unified",
                font=dict(color=TEXT_COLOR)
            )
            
            fig_equity.update_yaxes(title_text="Account Balance ($)", row=1, col=1)
            fig_equity.update_yaxes(title_text="Drawdown (%)", row=2, col=1)
            
            st.plotly_chart(fig_equity, use_container_width=True)
        else:
            st.markdown("""
            <div class="alert-box alert-warning">
                <p><strong>⚠️ No account balance data to display.</strong></p>
                <p>Add trades to view your compounding account balance over time. Ensure 'Equity' column is valid.</p>
            </div>
            """, unsafe_allow_html=True)
    
    with tab2:
        col1, col2 = st.columns(2)
        
        with col1:
            # Monthly Performance Heatmap
            if not df.empty and 'Date' in df.columns and 'R_Multiple' in df.columns and 'Risk%' in df.columns:
                df_copy_for_heatmap = df.copy()
                df_copy_for_heatmap['Month'] = df_copy_for_heatmap['Date'].dt.month
                df_copy_for_heatmap['Year'] = df_copy_for_heatmap['Date'].dt.year
                
                # Calculate monthly average R_Multiple or total R_Multiple for heatmap
                df_copy_for_heatmap['Monthly_Return_Abs'] = (df_copy_for_heatmap['R_Multiple'] * (df_copy_for_heatmap['Risk%'] / 100)) # Percentage return on total equity for that trade
                
                # Group by Year and Month, then sum the Monthly_Return_Abs
                monthly_total_returns = df_copy_for_heatmap.groupby(['Year', 'Month'])['Monthly_Return_Abs'].sum().reset_index()
                
                # Create a pivot table for the heatmap
                monthly_pivot = monthly_total_returns.pivot(index='Month', columns='Year', values='Monthly_Return_Abs')
                
                # Map month numbers to names
                month_names = {i: datetime(2000, i, 1).strftime('%b') for i in range(1, 13)}
                # Ensure all months are present as index and sorted
                monthly_pivot = monthly_pivot.rename(index=month_names).reindex([month_names[i] for i in range(1,13)], fill_value=np.nan)

                if not monthly_pivot.empty and not monthly_pivot.isnull().all().all(): # Check if it's not entirely NaN
                    fig_monthly_heatmap = go.Figure(data=go.Heatmap(
                        z=monthly_pivot.values * 100, # Convert to percentage for display
                        x=monthly_pivot.columns,
                        y=monthly_pivot.index,
                        colorscale=[[0, TV_RED], [0.5, PANEL_COLOR], [1, TV_GREEN]], # Red for negative, green for positive
                        zmin=monthly_pivot.min().min() * 1.2 if not monthly_pivot.min().isnull().all() else -10, # Extend range for better visualization
                        zmax=monthly_pivot.max().max() * 1.2 if not monthly_pivot.max().isnull().all() else 10,
                        colorbar=dict(title='Monthly Return (%)', titleside='right'),
                        hovertemplate="<b>%{y}, %{x}</b><br>Return: %{z:.2f}%<extra></extra>"
                    ))
                    
                    fig_monthly_heatmap.update_layout(
                        title='<b>Monthly Performance Heatmap (Total % Return)</b>',
                        xaxis_title='Year',
                        yaxis_title='Month',
                        template='plotly_dark',
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)',
                        height=500,
                        font=dict(color=TEXT_COLOR)
                    )
                    st.plotly_chart(fig_monthly_heatmap, use_container_width=True)
                else:
                    st.markdown("""
                    <div class="alert-box alert-warning">
                        <p><strong>⚠️ No monthly performance data to display heatmap.</strong></p>
                        <p>Add more trades to see your monthly trading performance.</p>
                    </div>
                    """, unsafe_allow_html=True)
            else:
                st.markdown("""
                <div class="alert-box alert-warning">
                    <p><strong>⚠️ No monthly performance data to display heatmap.</strong></p>
                    <p>Add more trades with valid 'Date', 'R_Multiple', and 'Risk%' values.</p>
                </div>
                """, unsafe_allow_html=True)
        
        with col2:
            # Hourly Performance Heatmap
            if not df.empty and 'Date' in df.columns and 'R_Multiple' in df.columns:
                df_copy_for_heatmap = df.copy()
                df_copy_for_heatmap['Hour'] = df_copy_for_heatmap['Date'].dt.hour
                hourly_returns = df_copy_for_heatmap.groupby(['Hour'])['R_Multiple'].mean().reset_index()

                if not hourly_returns.empty:
                    fig_hourly_heatmap = go.Figure(data=go.Heatmap(
                        z=[hourly_returns['R_Multiple'].values],
                        x=hourly_returns['Hour'],
                        y=['Avg R-Multiple'],
                        colorscale=[[0, TV_RED], [0.5, PANEL_COLOR], [1, TV_GREEN]],
                        zmin=hourly_returns['R_Multiple'].min() * 1.2 if hourly_returns['R_Multiple'].min() < 0 else 0, # Handle all positive R-Multiples
                        zmax=hourly_returns['R_Multiple'].max() * 1.2 if hourly_returns['R_Multiple'].max() > 0 else 1,
                        colorbar=dict(title='Avg R-Multiple', titleside='right'),
                        hovertemplate="<b>Hour: %{x}</b><br>Avg R-Multiple: %{z:.2f}<extra></extra>"
                    ))
                    
                    fig_hourly_heatmap.update_layout(
                        title='<b>Hourly Performance Heatmap (Avg R-Multiple)</b>',
                        xaxis_title='Hour of Day (24-hour format)',
                        yaxis_title='',
                        template='plotly_dark',
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)',
                        height=500,
                        font=dict(color=TEXT_COLOR)
                    )
                    st.plotly_chart(fig_hourly_heatmap, use_container_width=True)
                else:
                    st.markdown("""
                    <div class="alert-box alert-warning">
                        <p><strong>⚠️ No hourly performance data to display heatmap.</strong></p>
                        <p>Ensure trades have valid dates and R-Multiples.</p>
                    </div>
                    """, unsafe_allow_html=True)
            else:
                st.markdown("""
                <div class="alert-box alert-warning">
                    <p><strong>⚠️ No hourly performance data to display heatmap.</strong></p>
                    <p>Ensure trades have valid dates and R-Multiples.</p>
                </div>
                """, unsafe_allow_html=True)

    with tab3:
        st.markdown('<div class="section-header"><h3 class="section-title">🔍 Detailed Trade Analysis</h3></div>', unsafe_allow_html=True)
        col_t1, col_t2 = st.columns(2)

        with col_t1:
            # R-Multiple Distribution
            if not df.empty and 'R_Multiple' in df.columns and not df['R_Multiple'].isnull().all():
                fig_r_dist = px.histogram(df, x='R_Multiple', nbins=50,
                                        title='<b>R-Multiple Distribution</b>',
                                        color_discrete_sequence=[TV_BLUE],
                                        labels={'R_Multiple': 'R-Multiple'})
                fig_r_dist.update_traces(marker_line_width=1, marker_line_color=GRID_COLOR)
                fig_r_dist.update_layout(template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font=dict(color=TEXT_COLOR))
                st.plotly_chart(fig_r_dist, use_container_width=True)
            else:
                st.info("No trades to display R-Multiple Distribution.")
            
            # Trade Duration Distribution
            if not df.empty and 'Trade_Duration' in df.columns and not df['Trade_Duration'].isnull().all() and df['Trade_Duration'].sum() > 0:
                fig_duration_dist = px.histogram(df, x='Trade_Duration', nbins=50,
                                                title='<b>Trade Duration Distribution (Minutes)</b>',
                                                color_discrete_sequence=[TV_PURPLE],
                                                labels={'Trade_Duration': 'Duration (Minutes)'})
                fig_duration_dist.update_traces(marker_line_width=1, marker_line_color=GRID_COLOR)
                fig_duration_dist.update_layout(template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font=dict(color=TEXT_COLOR))
                st.plotly_chart(fig_duration_dist, use_container_width=True)
            else:
                st.info("No trade duration data available.")

        with col_t2:
            # MAE vs MFE Scatter Plot
            if 'MAE' in df.columns and 'MFE' in df.columns and not df[['MAE', 'MFE']].isnull().all().all() and (df['MAE'].sum() > 0 or df['MFE'].sum() > 0):
                fig_mae_mfe = px.scatter(df, x='MAE', y='MFE', color='Outcome',
                                         title='<b>MAE vs MFE</b>',
                                         labels={'MAE': 'Max Adverse Excursion (Pips)', 'MFE': 'Max Favorable Excursion (Pips)'},
                                         color_discrete_map={'Win': TV_GREEN, 'Loss': TV_RED, 'Breakeven': TV_YELLOW},
                                         hover_data=['Pair', 'R_Multiple', 'Strategy', 'Comment'])
                
                # Add 45-degree line for MAE=MFE
                # Ensure max_val calculation is robust for empty or all-zero columns
                max_mae = df['MAE'].max() if not df['MAE'].isnull().all() else 0
                max_mfe = df['MFE'].max() if not df['MFE'].isnull().all() else 0
                max_val = max(max_mae, max_mfe)
                
                # Only add line if there's meaningful data range
                if max_val > 0:
                    fig_mae_mfe.add_trace(go.Scatter(x=[0, max_val * 1.1],
                                                     y=[0, max_val * 1.1],
                                                     mode='lines',
                                                     name='Break Even Line (MAE=MFE)',
                                                     line=dict(dash='dash', color=TV_CYAN)))
                
                fig_mae_mfe.update_layout(template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font=dict(color=TEXT_COLOR))
                st.plotly_chart(fig_mae_mfe, use_container_width=True)
            else:
                st.markdown("""
                <div class="alert-box alert-warning">
                    <p><strong>⚠️ No MAE/MFE data available for scatter plot.</strong></p>
                    <p>Please enter 'MAE' and 'MFE' values when adding trades.</p>
                </div>
                """, unsafe_allow_html=True)

            # Performance by Category (e.g., Strategy, Pair, Session)
            category_choice = st.selectbox("Analyze Performance by:", ['Strategy', 'Pair', 'Session', 'Market_Condition', 'Setup_Quality'], key="category_analysis_select")
            
            if category_choice in df.columns and not df.empty and not df[category_choice].isnull().all():
                perf_by_category = df.groupby(category_choice)['R_Multiple'].agg(['mean', 'sum', 'count']).reset_index()
                perf_by_category.columns = [category_choice, 'Avg R-Multiple', 'Total R-Multiple', 'Trade Count']
                perf_by_category = perf_by_category.sort_values('Total R-Multiple', ascending=False)
                
                if not perf_by_category.empty:
                    fig_cat_perf = px.bar(perf_by_category, x=category_choice, y='Total R-Multiple',
                                          color='Total R-Multiple',
                                          color_continuous_scale=[TV_RED, PANEL_COLOR, TV_GREEN],
                                          title=f'<b>Total R-Multiple by {category_choice}</b>',
                                          labels={'Total R-Multiple': 'Total R-Multiple'})
                    fig_cat_perf.update_layout(template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font=dict(color=TEXT_COLOR))
                    st.plotly_chart(fig_cat_perf, use_container_width=True)
                else:
                    st.markdown(f"""
                    <div class="alert-box alert-warning">
                        <p><strong>⚠️ No performance data for '{category_choice}' to display.</strong></p>
                        <p>Ensure trades have valid '{category_choice}' and 'R_Multiple' data.</p>
                    </div>
                    """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="alert-box alert-warning">
                    <p><strong>⚠️ Cannot analyze by '{category_choice}'.</strong></p>
                    <p>Ensure trades have '{category_choice}' data.</p>
                </div>
                """, unsafe_allow_html=True)
            
            # Win/Loss/Breakeven Pie Chart
            if not df.empty and 'Outcome' in df.columns:
                outcome_counts = df['Outcome'].value_counts()
                if not outcome_counts.empty:
                    fig_pie = px.pie(names=outcome_counts.index, values=outcome_counts.values,
                                     title='<b>Trade Outcome Distribution</b>',
                                     color=outcome_counts.index,
                                     color_discrete_map={'Win': TV_GREEN, 'Loss': TV_RED, 'Breakeven': TV_YELLOW},
                                     hole=0.4) # Make it a donut chart
                    fig_pie.update_traces(textinfo='percent+label', pull=[0.05 if x == 'Win' else 0 for x in outcome_counts.index])
                    fig_pie.update_layout(template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font=dict(color=TEXT_COLOR))
                    st.plotly_chart(fig_pie, use_container_width=True)
                else:
                    st.info("No trade outcomes to display pie chart.")
            else:
                st.info("No trade outcomes to display pie chart.")

    with tab4:
        st.markdown('<div class="section-header"><h3 class="section-title">⚡ Risk Metrics & Management</h3></div>', unsafe_allow_html=True)
        col_r1, col_r2 = st.columns(2)

        with col_r1:
            # Daily P&L Distribution
            if not df.empty and 'Risk%' in df.columns and 'R_Multiple' in df.columns and 'Date' in df.columns:
                df_copy_for_pnl = df.copy()
                df_copy_for_pnl['Daily_Return_Pct'] = (df_copy_for_pnl['R_Multiple'] * df_copy_for_pnl['Risk%']) # Percentage of initial equity for that trade
                daily_pnl = df_copy_for_pnl.groupby(df_copy_for_pnl['Date'].dt.date)['Daily_Return_Pct'].sum().reset_index()
                daily_pnl.columns = ['Date', 'Daily_P&L_Pct']

                if not daily_pnl.empty:
                    fig_daily_pnl = px.histogram(daily_pnl, x='Daily_P&L_Pct', nbins=50,
                                                 title='<b>Daily P&L Distribution (%)</b>',
                                                 color_discrete_sequence=[TV_ORANGE])
                    fig_daily_pnl.update_traces(marker_line_width=1, marker_line_color=GRID_COLOR)
                    fig_daily_pnl.update_layout(template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font=dict(color=TEXT_COLOR))
                    st.plotly_chart(fig_daily_pnl, use_container_width=True)
                else:
                    st.info("No daily P&L data available for histogram.")
            else:
                st.info("No daily P&L data available (missing 'Date', 'Risk%', or 'R_Multiple').")
            
            # Risk of Ruin Calculation (Simplified)
            st.markdown("<h4>Risk of Ruin Estimation (Simulation)</h4>", unsafe_allow_html=True)
            if not df.empty and 'Risk%' in df.columns and 'R_Multiple' in df.columns:
                # Filter out trades that result in no change (R_Multiple * Risk% == 0) for RoR
                returns_on_equity = (df['R_Multiple'] * df['Risk%' ] / 100).dropna().values
                returns_on_equity = returns_on_equity[returns_on_equity != 0]

                if len(returns_on_equity) > 1: # Needs at least 2 for meaningful simulation
                    num_simulations = st.number_input("Number of Simulations for RoR", 100, 10000, 1000, key="ror_sims")
                    bankruptcy_level = st.number_input("Bankruptcy Level (Equity % of starting)", 0.0, 99.9, 50.0, 5.0, key="ror_bankruptcy_level") / 100.0
                    
                    ruin_count = 0
                    for _ in range(num_simulations):
                        simulated_equity_path = [st.session_state.starting_equity]
                        for _ in range(st.session_state.backtest_period): # Number of trades to simulate
                            if simulated_equity_path[-1] <= st.session_state.starting_equity * bankruptcy_level:
                                ruin_count += 1
                                break
                            # Use np.random.choice to pick a random historical return
                            random_return = np.random.choice(returns_on_equity)
                            simulated_equity_path.append(simulated_equity_path[-1] * (1 + random_return))
                    
                    risk_of_ruin = (ruin_count / num_simulations) * 100
                    st.markdown(f"""
                    <div class="alert-box alert-info">
                        <p>Estimated Risk of Ruin ({bankruptcy_level*100:.0f}% Bankruptcy): <strong>{risk_of_ruin:.2f}%</strong></p>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.warning("Insufficient historical returns data (at least 2 trades with non-zero risk/R-multiple) for Risk of Ruin calculation.")
            else:
                st.info("No trades available for Risk of Ruin calculation.")

        with col_r2:
            # Consecutive Wins/Losses Distribution
            st.markdown("<h4>Consecutive Streaks Distribution</h4>", unsafe_allow_html=True)
            if not df.empty and 'R_Multiple' in df.columns:
                returns = df['R_Multiple'].values
                current_win_streak = 0
                current_loss_streak = 0
                win_streaks = []
                loss_streaks = []

                for r in returns:
                    if r > 0:
                        current_win_streak += 1
                        if current_loss_streak > 0:
                            loss_streaks.append(current_loss_streak)
                        current_loss_streak = 0
                    elif r < 0:
                        current_loss_streak += 1
                        if current_win_streak > 0:
                            win_streaks.append(current_win_streak)
                        current_win_streak = 0
                    else: # Breakeven, reset both
                        if current_win_streak > 0:
                            win_streaks.append(current_win_streak)
                        if current_loss_streak > 0:
                            loss_streaks.append(current_loss_streak)
                        current_win_streak = 0
                        current_loss_streak = 0
                
                # Append any remaining streaks
                if current_win_streak > 0:
                    win_streaks.append(current_win_streak)
                if current_loss_streak > 0:
                    loss_streaks.append(current_loss_streak)
                
                if win_streaks or loss_streaks:
                    fig_streaks = make_subplots(rows=1, cols=2, subplot_titles=('Win Streaks', 'Loss Streaks'))
                    
                    # Use value_counts to get frequencies and then sort for histogram
                    win_streak_counts = pd.Series(win_streaks).value_counts().sort_index()
                    loss_streak_counts = pd.Series(loss_streaks).value_counts().sort_index()

                    if not win_streak_counts.empty:
                        fig_streaks.add_trace(go.Bar(x=win_streak_counts.index, y=win_streak_counts.values,
                                                           name='Wins', marker_color=TV_GREEN, opacity=0.8), row=1, col=1)
                    if not loss_streak_counts.empty:
                        fig_streaks.add_trace(go.Bar(x=loss_streak_counts.index, y=loss_streak_counts.values,
                                                           name='Losses', marker_color=TV_RED, opacity=0.8), row=1, col=2)
                    
                    fig_streaks.update_layout(template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)',
                                               title_text='<b>Distribution of Win and Loss Streaks</b>',
                                               font=dict(color=TEXT_COLOR))
                    fig_streaks.update_xaxes(title_text="Streak Length")
                    fig_streaks.update_yaxes(title_text="Frequency")
                    st.plotly_chart(fig_streaks, use_container_width=True)
                else:
                    st.info("No sufficient trade history to analyze streaks.")
            else:
                st.info("No trades available to analyze streaks.")

    with tab5:
        st.markdown('<div class="section-header"><h3 class="section-title">📈 Strategy Optimization & Deep Dive</h3></div>', unsafe_allow_html=True)

        st.info("This section provides a deeper dive into your strategies. It allows you to analyze specific strategies and identify areas for potential optimization. Make sure your trades have 'Strategy' assigned for best results.")

        # Filter trades by strategy
        # Ensure 'Strategy' column exists before getting unique values
        available_strategies = df['Strategy'].unique().tolist() if 'Strategy' in df.columns and not df['Strategy'].isnull().all() else []
        
        # Add "N/A" if it's not already in the list
        if "N/A" not in available_strategies:
            available_strategies.append("N/A")
        available_strategies = sorted([s for s in available_strategies if s != 'N/A']) + ['N/A'] # Put N/A at the end

        selected_strategy = st.selectbox("Select Strategy for Analysis:", ["All"] + available_strategies, key="strategy_analysis_select")

        filtered_df = df if selected_strategy == "All" else df[df['Strategy'] == selected_strategy]

        if not filtered_df.empty:
            strategy_metrics = calculate_advanced_metrics(filtered_df)
            st.markdown(f"<h4>Metrics for '{selected_strategy}' Strategy:</h4>", unsafe_allow_html=True)
            cols_strategy_metrics = st.columns(3)
            with cols_strategy_metrics[0]:
                st.metric("Win Rate", f"{strategy_metrics.get('win_rate', 0):.1f}%")
            with cols_strategy_metrics[1]:
                st.metric("Profit Factor", f"{strategy_metrics.get('profit_factor', 0):.2f}")
            with cols_strategy_metrics[2]:
                st.metric("Expectancy", f"{strategy_metrics.get('expectancy', 0):.3f}R")
            
            st.markdown("---")
            st.markdown("<h4>Trade Distribution by Setup Quality for Selected Strategy:</h4>", unsafe_allow_html=True)
            
            if 'Setup_Quality' in filtered_df.columns and not filtered_df['Setup_Quality'].isnull().all():
                setup_quality_dist = filtered_df.groupby(['Setup_Quality', 'Outcome']).size().unstack(fill_value=0)
                
                # Filter to only include columns that actually exist in the unstacked DataFrame
                # And reindex to ensure a consistent order
                outcome_cols = ['Win', 'Loss', 'Breakeven']
                present_outcome_cols = [col for col in outcome_cols if col in setup_quality_dist.columns]
                
                # Order by a defined quality order, including 'N/A'
                quality_order = ["A+", "A", "B", "C", "D", "N/A"] 
                # Reindex and fill any missing quality levels with zeros
                setup_quality_dist = setup_quality_dist.reindex(quality_order, axis=0).fillna(0)
                
                # Drop rows where all outcome columns are zero (i.e., no trades for that quality)
                setup_quality_dist = setup_quality_dist.loc[(setup_quality_dist[present_outcome_cols] != 0).any(axis=1)]


                if not setup_quality_dist.empty and present_outcome_cols: # Check if there's data to plot
                    fig_setup_quality = px.bar(setup_quality_dist, 
                                               x=setup_quality_dist.index, 
                                               y=present_outcome_cols, # Use only present columns
                                               title=f"<b>Trade Outcome by Setup Quality ({selected_strategy})</b>",
                                               color_discrete_map={'Win': TV_GREEN, 'Loss': TV_RED, 'Breakeven': TV_YELLOW})
                    fig_setup_quality.update_layout(barmode='stack', template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)',
                                                    xaxis_title="Setup Quality", yaxis_title="Number of Trades", font=dict(color=TEXT_COLOR))
                    st.plotly_chart(fig_setup_quality, use_container_width=True)
                else:
                    st.info(f"No setup quality data to display for '{selected_strategy}' strategy or no trades recorded for selected quality types.")
            else:
                st.info("No 'Setup Quality' data available for this strategy. Please ensure trades have 'Setup Quality' assigned.")


            st.markdown("---")
            st.markdown("<h4>Market Condition Impact for Selected Strategy:</h4>", unsafe_allow_html=True)
            
            if 'Market_Condition' in filtered_df.columns and not filtered_df['Market_Condition'].isnull().all():
                market_condition_impact = filtered_df.groupby('Market_Condition')['R_Multiple'].agg(['mean', 'sum', 'count']).reset_index()
                market_condition_impact.columns = ['Market_Condition', 'Avg R-Multiple', 'Total R-Multiple', 'Trade Count']
                market_condition_impact = market_condition_impact.sort_values('Total R-Multiple', ascending=False)

                if not market_condition_impact.empty:
                    fig_market_condition = px.bar(market_condition_impact, x='Market_Condition', y='Total R-Multiple',
                                                  color='Total R-Multiple',
                                                  color_continuous_scale=[TV_RED, PANEL_COLOR, TV_GREEN],
                                                  title=f"<b>Total R-Multiple by Market Condition ({selected_strategy})</b>")
                    fig_market_condition.update_layout(template='plotly_dark', plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)',
                                                        xaxis_title="Market Condition", yaxis_title="Total R-Multiple", font=dict(color=TEXT_COLOR))
                    st.plotly_chart(fig_market_condition, use_container_width=True)
                else:
                    st.info(f"No market condition data to display for '{selected_strategy}' strategy or no trades recorded for selected market conditions.")
            else:
                st.info("No 'Market Condition' data available for this strategy. Please ensure trades have 'Market Condition' assigned.")

            # Hypothetical Scenario Testing
            st.markdown("---")
            st.markdown("<h4>Hypothetical Scenario Testing:</h4>", unsafe_allow_html=True)
            st.write("Simulate performance if you only took trades based on certain criteria.")
            
            col_hypo1, col_hypo2 = st.columns(2)
            with col_hypo1:
                hypo_pair_options = ["All"] + df['Pair'].unique().tolist() if 'Pair' in df.columns and not df['Pair'].isnull().all() else ["All"]
                hypo_pair = st.selectbox("Test for Pair:", hypo_pair_options, key="hypo_pair_select")
            with col_hypo2:
                hypo_min_r = st.slider("Minimum R-Multiple to consider:", -1.0, 5.0, 0.5, 0.1, key="hypo_min_r_slider")

            hypothetical_df = filtered_df.copy()
            if hypo_pair != "All":
                hypothetical_df = hypothetical_df[hypothetical_df['Pair'] == hypo_pair]
            
            hypothetical_df = hypothetical_df[hypothetical_df['R_Multiple'] >= hypo_min_r]

            if not hypothetical_df.empty:
                hypo_metrics = calculate_advanced_metrics(hypothetical_df)
                st.markdown(f"""
                <div class="stat-grid">
                    <div class="stat-item">
                        <div class="stat-label">Hypo Total Trades</div>
                        <div class="stat-value">{hypo_metrics.get('total_trades', 0)}</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Hypo Win Rate</div>
                        <div class="stat-value">{hypo_metrics.get('win_rate', 0):.1f}%</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Hypo Profit Factor</div>
                        <div class="stat-value">{hypo_metrics.get('profit_factor', 0):.2f}</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Hypo Max Drawdown</div>
                        <div class="stat-value">{hypo_metrics.get('max_drawdown', 0):.1f}%</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown("""
                <div class="alert-box alert-warning">
                    <p><strong>⚠️ No trades match the hypothetical criteria.</strong></p>
                    <p>Adjust your filters to see results.</p>
                </div>
                """, unsafe_allow_html=True)

        else:
            st.info("No trades available for strategy deep dive. Add trades and assign them to strategies to use this feature.")


    # Current Performance vs. Targets
    st.markdown('<div class="section-header"><h2 class="section-title">🎯 Performance vs. Targets</h2></div>', unsafe_allow_html=True)
    
    current_profit_pct = (st.session_state.equity / st.session_state.starting_equity - 1) * 100 if st.session_state.starting_equity != 0 else 0
    
    # Calculate actual average monthly return from equity curve
    actual_avg_monthly_return = 0
    if len(df) > 1 and (df['Date'].max() - df['Date'].min()).days > 0:
        # Calculate monthly returns from equity curve
        df_monthly_end = df.set_index('Date').resample('M')['Equity'].last()
        df_monthly_return = df_monthly_end.pct_change().dropna()
        actual_avg_monthly_return = df_monthly_return.mean() * 100 if not df_monthly_return.empty else 0

    col_targets = st.columns(3)
    
    with col_targets[0]:
        target_met_monthly = actual_avg_monthly_return >= st.session_state.performance_targets['monthly_return']
        st.markdown(f"""
        <div class="stat-item">
            <div class="stat-label">Avg. Monthly Return (%)</div>
            <div class="stat-value" style="color: {TV_GREEN if target_met_monthly else TV_RED};">{actual_avg_monthly_return:.1f}%</div>
            <div class="stat-label">Target: {st.session_state.performance_targets['monthly_return']:.1f}% {('✅' if target_met_monthly else '❌')}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col_targets[1]:
        target_met_drawdown = abs(metrics['max_drawdown']) <= st.session_state.performance_targets['max_drawdown']
        st.markdown(f"""
        <div class="stat-item">
            <div class="stat-label">Max Drawdown (%)</div>
            <div class="stat-value" style="color: {TV_GREEN if target_met_drawdown else TV_RED};">{metrics['max_drawdown']:.1f}%</div>
            <div class="stat-label">Target: &lt; {st.session_state.performance_targets['max_drawdown']:.1f}% {('✅' if target_met_drawdown else '❌')}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col_targets[2]:
        target_met_sharpe = metrics['sharpe_ratio'] >= st.session_state.performance_targets['sharpe_ratio']
        st.markdown(f"""
        <div class="stat-item">
            <div class="stat-label">Sharpe Ratio</div>
            <div class="stat-value" style="color: {TV_GREEN if target_met_sharpe else TV_RED};">{metrics['sharpe_ratio']:.2f}</div>
            <div class="stat-label">Target: &gt; {st.session_state.performance_targets['sharpe_ratio']:.1f} {('✅' if target_met_sharpe else '❌')}</div>
        </div>
        """, unsafe_allow_html=True)

    # Full Trade Log Display
    st.markdown('<div class="section-header"><h2 class="section-title">📋 Full Trade Log</h2></div>', unsafe_allow_html=True)
    
    # Ensure 'Outcome' column exists before styling
    if 'Outcome' in df.columns:
        st.dataframe(df.style.applymap(lambda x: f'background-color: {TV_GREEN}20' if x == 'Win' else (f'background-color: {TV_RED}20' if x == 'Loss' else f'background-color: {TV_YELLOW}20'), subset=['Outcome']), use_container_width=True)
    else:
        st.dataframe(df, use_container_width=True)

    # Export Data
    csv_file = df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Export Trade Data to CSV",
        data=csv_file,
        file_name=f"forex_trades_{st.session_state.current_journal}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        mime="text/csv",
        use_container_width=True
    )
